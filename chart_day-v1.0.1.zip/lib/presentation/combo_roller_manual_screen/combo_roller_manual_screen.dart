import 'controller/combo_roller_manual_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:chart_day/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class ComboRollerManualScreen extends GetWidget<ComboRollerManualController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin:
                          getMargin(left: 60, top: 13, right: 60, bottom: 13),
                      onTap: onTapHome)
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 7, right: 7),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      GestureDetector(
                          onTap: () {
                            onTapTxtCriticalHitChart();
                          },
                          child: Text("msg_critical_hit_chart".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAlgerian20.copyWith(
                                  letterSpacing: getHorizontalSize(0.8)))),
                      Padding(
                          padding: getPadding(top: 29),
                          child: Text("lbl_enter_your_roll".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium22.copyWith(
                                  letterSpacing: getHorizontalSize(0.44)))),
                      Container(
                          height: getVerticalSize(124),
                          width: getHorizontalSize(250),
                          margin: getMargin(top: 43),
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(5)),
                              border: Border.all(
                                  color: ColorConstant.lightBlueA7007f,
                                  width: getHorizontalSize(3)))),
                      Spacer(),
                      Container(
                          height: getVerticalSize(216),
                          width: getHorizontalSize(375),
                          margin: getMargin(bottom: 30),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: fs.Svg(ImageConstant.imgGroup35),
                                  fit: BoxFit.cover)),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                    padding: getPadding(
                                        left: 44,
                                        top: 17,
                                        right: 44,
                                        bottom: 17),
                                    decoration:
                                        AppDecoration.outlineLightgreen600,
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_save".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterMedium13))
                                        ]))),
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: fs.Svg(
                                                ImageConstant.imgGroup35),
                                            fit: BoxFit.cover)),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          CustomButton(
                                              height: getVerticalSize(54),
                                              width: getHorizontalSize(122),
                                              text: "lbl_1d_100".tr,
                                              margin: getMargin(top: 162),
                                              variant: ButtonVariant
                                                  .OutlineBlack9003f,
                                              shape: ButtonShape.Square,
                                              fontStyle:
                                                  ButtonFontStyle.Algerian20)
                                        ])))
                          ]))
                    ]))));
  }

  onTapTxtCriticalHitChart() {
    Get.toNamed(AppRoutes.comboRollerMainContainerScreen);
  }

  onTapVolume() {
    Get.toNamed(AppRoutes.comboRollerMainContainerScreen);
  }

  onTapHome() {
    Get.toNamed(AppRoutes.chartListScreen);
  }
}
