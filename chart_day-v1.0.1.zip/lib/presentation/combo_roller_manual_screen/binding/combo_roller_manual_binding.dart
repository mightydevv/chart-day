import '../controller/combo_roller_manual_controller.dart';
import 'package:get/get.dart';

class ComboRollerManualBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ComboRollerManualController());
  }
}
