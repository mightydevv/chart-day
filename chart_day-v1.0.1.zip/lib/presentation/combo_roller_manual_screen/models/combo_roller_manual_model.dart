class ComboRollerManualModel {}
