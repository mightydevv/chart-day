import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/combo_roller_manual_screen/models/combo_roller_manual_model.dart';

class ComboRollerManualController extends GetxController {
  Rx<ComboRollerManualModel> comboRollerManualModelObj =
      ComboRollerManualModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
