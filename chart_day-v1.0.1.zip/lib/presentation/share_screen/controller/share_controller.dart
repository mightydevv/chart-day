import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/share_screen/models/share_model.dart';

class ShareController extends GetxController {
  Rx<ShareModel> shareModelObj = ShareModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
