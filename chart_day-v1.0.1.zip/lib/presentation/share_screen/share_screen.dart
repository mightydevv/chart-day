import 'controller/share_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class ShareScreen extends GetWidget<ShareController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume5),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin:
                          getMargin(left: 60, top: 13, right: 60, bottom: 13),
                      onTap: onTapHome2)
                ]),
            body: Container(
                width: double.maxFinite,
                child:
                    Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Padding(
                      padding: getPadding(top: 62),
                      child: Text("msg_critical_hit_chart".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian30.copyWith(
                              letterSpacing: getHorizontalSize(1.2)))),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                          padding: getPadding(top: 31, right: 39),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    imagePath: ImageConstant.imgQrpng1,
                                    height: getSize(200),
                                    width: getSize(200),
                                    margin: getMargin(bottom: 19)),
                                CustomImageView(
                                    svgPath: ImageConstant.imgFile,
                                    height: getSize(30),
                                    width: getSize(30),
                                    margin: getMargin(left: 26, top: 189))
                              ]))),
                  Container(
                      height: getVerticalSize(117),
                      width: double.maxFinite,
                      margin: getMargin(top: 40),
                      child: Stack(alignment: Alignment.topCenter, children: [
                        Align(
                            alignment: Alignment.center,
                            child: Container(
                                height: getVerticalSize(116),
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: ColorConstant.black900,
                                        width: getHorizontalSize(1))))),
                        Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                                width: getHorizontalSize(229),
                                child: Text("msg_original_author".tr,
                                    maxLines: null,
                                    textAlign: TextAlign.center,
                                    style: AppStyle.txtBradleyHandITC17
                                        .copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.68)))))
                      ])),
                  CustomImageView(
                      imagePath: ImageConstant.imgImg42191,
                      height: getVerticalSize(233),
                      width: getHorizontalSize(390))
                ]))));
  }

  onTapVolume5() {
    Get.toNamed(AppRoutes.chartListScreen);
  }

  onTapHome2() {
    Get.toNamed(AppRoutes.chartListScreen);
  }
}
