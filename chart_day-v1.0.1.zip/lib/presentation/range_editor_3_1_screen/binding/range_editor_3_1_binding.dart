import '../controller/range_editor_3_1_controller.dart';
import 'package:get/get.dart';

class RangeEditor31Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RangeEditor31Controller());
  }
}
