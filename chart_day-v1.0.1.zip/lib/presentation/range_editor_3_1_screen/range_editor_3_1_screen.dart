import 'controller/range_editor_3_1_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:chart_day/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class RangeEditor31Screen extends GetWidget<RangeEditor31Controller> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume3),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin: getMargin(left: 15, top: 13, right: 13)),
                  AppbarImage(
                      height: getVerticalSize(22),
                      width: getHorizontalSize(20),
                      svgPath: ImageConstant.imgPlay,
                      margin:
                          getMargin(left: 25, top: 17, right: 28, bottom: 4))
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 7, right: 7),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("msg_critical_hit_chart".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian20
                              .copyWith(letterSpacing: getHorizontalSize(0.8))),
                      Padding(
                          padding: getPadding(top: 13),
                          child: Text("lbl_select_range".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17.copyWith(
                                  letterSpacing: getHorizontalSize(0.34)))),
                      Padding(
                          padding: getPadding(top: 9),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomButton(
                                    height: getVerticalSize(70),
                                    width: getHorizontalSize(80),
                                    text: "lbl_55".tr),
                                Padding(
                                    padding:
                                        getPadding(left: 36, top: 8, bottom: 8),
                                    child: Text("lbl".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtAlgerian40.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(1.6)))),
                                CustomButton(
                                    height: getVerticalSize(70),
                                    width: getHorizontalSize(80),
                                    text: "lbl_100".tr,
                                    margin: getMargin(left: 40),
                                    padding: ButtonPadding.PaddingT15)
                              ])),
                      Padding(
                          padding: getPadding(left: 12, top: 1, right: 7),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: getHorizontalSize(20),
                                    margin: getMargin(top: 10, bottom: 5),
                                    child: Text("lbl_1_09".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtAlgerian15.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.6)))),
                                Container(
                                    padding: getPadding(
                                        left: 13, top: 3, right: 13, bottom: 3),
                                    decoration: AppDecoration.outlineBlack9003f
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text("msg_intimidating_next".tr,
                                              maxLines: null,
                                              textAlign: TextAlign.center,
                                              style: AppStyle
                                                  .txtBradleyHandITC18
                                                  .copyWith(
                                                      letterSpacing:
                                                          getHorizontalSize(
                                                              0.72)))
                                        ]))
                              ])),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 7, top: 54, right: 50),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                        width: getHorizontalSize(28),
                                        child: Text("lbl_10_49".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle.txtAlgerian15
                                                .copyWith(
                                                    letterSpacing:
                                                        getHorizontalSize(
                                                            0.6)))),
                                    CustomImageView(
                                        svgPath:
                                            ImageConstant.imgClickableplace,
                                        height: getVerticalSize(34),
                                        width: getHorizontalSize(216),
                                        margin: getMargin(top: 2, bottom: 3))
                                  ]))),
                      Padding(
                          padding: getPadding(left: 6, top: 41, right: 7),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: getHorizontalSize(29),
                                    margin: getMargin(top: 18, bottom: 17),
                                    child: Text("lbl_50_54".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtAlgerian15.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.6)))),
                                Container(
                                    padding: getPadding(
                                        left: 34, top: 1, right: 34, bottom: 1),
                                    decoration: AppDecoration.outlineBlack9003f
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder10),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding: getPadding(top: 1),
                                              child: Text(
                                                  "msg_great_strike_you".tr,
                                                  maxLines: null,
                                                  textAlign: TextAlign.center,
                                                  style: AppStyle
                                                      .txtBradleyHandITC18
                                                      .copyWith(
                                                          letterSpacing:
                                                              getHorizontalSize(
                                                                  0.72))))
                                        ]))
                              ])),
                      Padding(
                          padding: getPadding(left: 6, top: 43, right: 7),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: getHorizontalSize(31),
                                    child: Text("lbl_55_100".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtAlgerian15.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.6)))),
                                Container(
                                    height: getVerticalSize(35),
                                    width: getHorizontalSize(309),
                                    margin: getMargin(top: 1, bottom: 3),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        border: Border.all(
                                            color:
                                                ColorConstant.lightBlueA7007f,
                                            width: getHorizontalSize(2),
                                            strokeAlign: StrokeAlign.center)))
                              ])),
                      Container(
                          height: getVerticalSize(214),
                          width: getHorizontalSize(375),
                          margin: getMargin(top: 22, bottom: 5),
                          child:
                              Stack(alignment: Alignment.bottomLeft, children: [
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    padding: getPadding(
                                        left: 3, top: 4, right: 3, bottom: 4),
                                    decoration: AppDecoration.outlineBlack900,
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Container(
                                              height: getVerticalSize(42),
                                              width: getHorizontalSize(126),
                                              margin: getMargin(top: 164),
                                              decoration: BoxDecoration(
                                                  color:
                                                      ColorConstant.blueGray300,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          getHorizontalSize(5)),
                                                  boxShadow: [
                                                    BoxShadow(
                                                        color: ColorConstant
                                                            .black9003f,
                                                        spreadRadius:
                                                            getHorizontalSize(
                                                                2),
                                                        blurRadius:
                                                            getHorizontalSize(
                                                                2),
                                                        offset: Offset(0, 4))
                                                  ]))
                                        ]))),
                            Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                    padding: getPadding(left: 29, bottom: 10),
                                    child: Text("lbl_1d_100".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtAlgerian20.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.8)))))
                          ]))
                    ]))));
  }

  onTapVolume3() {
    Get.toNamed(AppRoutes.diceSelectorScreen);
  }
}
