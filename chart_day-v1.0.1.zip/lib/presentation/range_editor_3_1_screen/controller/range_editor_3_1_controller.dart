import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/range_editor_3_1_screen/models/range_editor_3_1_model.dart';

class RangeEditor31Controller extends GetxController {
  Rx<RangeEditor31Model> rangeEditor31ModelObj = RangeEditor31Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
