import 'controller/combo_roller_main_controller.dart';
import 'models/combo_roller_main_model.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class ComboRollerMainPage extends StatelessWidget {
  ComboRollerMainController controller =
      Get.put(ComboRollerMainController(ComboRollerMainModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(56),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume1),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin:
                          getMargin(left: 60, top: 13, right: 60, bottom: 13),
                      onTap: onTapHome1)
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 18, right: 18),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("msg_critical_hit_chart".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian20
                              .copyWith(letterSpacing: getHorizontalSize(0.8))),
                      Container(
                          height: getVerticalSize(280),
                          width: getHorizontalSize(298),
                          margin: getMargin(top: 31),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.topCenter,
                                child: Text("lbl_random_roller".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterMedium17)),
                            CustomImageView(
                                imagePath:
                                    ImageConstant.imgDicetrayremovebgpreview,
                                height: getVerticalSize(267),
                                width: getHorizontalSize(298),
                                alignment: Alignment.center)
                          ])),
                      Padding(
                          padding: getPadding(top: 16),
                          child: Text("msg_manually_enter_rolls".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17)),
                      GestureDetector(
                          onTap: () {
                            onTapDivdeField();
                          },
                          child: Container(
                              height: getVerticalSize(124),
                              width: getHorizontalSize(250),
                              margin: getMargin(top: 7),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      getHorizontalSize(5)),
                                  border: Border.all(
                                      color: ColorConstant.lightBlueA7007f,
                                      width: getHorizontalSize(3))))),
                      Spacer(),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Text("lbl_1d_100".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAlgerian18.copyWith(
                                  letterSpacing: getHorizontalSize(0.72))))
                    ]))));
  }

  onTapDivdeField() {
    Get.toNamed(AppRoutes.comboRollerManualScreen);
  }

  onTapVolume1() {
    Get.toNamed(AppRoutes.chartListScreen);
  }

  onTapHome1() {
    Get.toNamed(AppRoutes.chartListScreen);
  }
}
