import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/combo_roller_main_page/models/combo_roller_main_model.dart';

class ComboRollerMainController extends GetxController {
  ComboRollerMainController(this.comboRollerMainModelObj);

  Rx<ComboRollerMainModel> comboRollerMainModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
