import '../controller/combo_roller_main_container_controller.dart';
import 'package:get/get.dart';

class ComboRollerMainContainerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ComboRollerMainContainerController());
  }
}
