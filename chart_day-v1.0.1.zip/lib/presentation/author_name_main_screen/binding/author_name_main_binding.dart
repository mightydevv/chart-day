import '../controller/author_name_main_controller.dart';
import 'package:get/get.dart';

class AuthorNameMainBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AuthorNameMainController());
  }
}
