import 'controller/author_name_main_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class AuthorNameMainScreen extends GetWidget<AuthorNameMainController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume6),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin:
                          getMargin(left: 60, top: 13, right: 60, bottom: 13),
                      onTap: onTapHome3)
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(top: 30, bottom: 30),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                          padding: getPadding(top: 30),
                          child: Text("lbl_your_name".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAlgerian30.copyWith(
                                  letterSpacing: getHorizontalSize(1.2)))),
                      Container(
                          height: getVerticalSize(124),
                          width: getHorizontalSize(295),
                          margin: getMargin(top: 19),
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(10)),
                              border: Border.all(
                                  color: ColorConstant.lightBlueA7007f,
                                  width: getHorizontalSize(2)))),
                      Container(
                          height: getVerticalSize(90),
                          width: double.maxFinite,
                          margin: getMargin(top: 26),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                    height: getVerticalSize(78),
                                    width: double.maxFinite,
                                    margin: getMargin(top: 1),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: ColorConstant.black900,
                                            width: getHorizontalSize(1))))),
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    width: getHorizontalSize(281),
                                    child: Text("msg_original_author2".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtBradleyHandITC17
                                            .copyWith(
                                                letterSpacing:
                                                    getHorizontalSize(0.68)))))
                          ])),
                      Spacer(),
                      Container(
                          width: getHorizontalSize(375),
                          margin: getMargin(left: 8, right: 7),
                          padding:
                              getPadding(left: 3, top: 4, right: 3, bottom: 4),
                          decoration: AppDecoration.outlineBlack900,
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                    height: getVerticalSize(42),
                                    width: getHorizontalSize(126),
                                    margin: getMargin(top: 164),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray300,
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(5)),
                                        boxShadow: [
                                          BoxShadow(
                                              color: ColorConstant.black9003f,
                                              spreadRadius:
                                                  getHorizontalSize(2),
                                              blurRadius: getHorizontalSize(2),
                                              offset: Offset(0, 4))
                                        ]))
                              ]))
                    ]))));
  }

  onTapVolume6() {
    Get.toNamed(AppRoutes.chartListScreen);
  }

  onTapHome3() {
    Get.toNamed(AppRoutes.chartListScreen);
  }
}
