import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/author_name_main_screen/models/author_name_main_model.dart';

class AuthorNameMainController extends GetxController {
  Rx<AuthorNameMainModel> authorNameMainModelObj = AuthorNameMainModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
