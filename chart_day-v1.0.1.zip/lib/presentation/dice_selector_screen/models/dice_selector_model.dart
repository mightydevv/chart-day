class DiceSelectorModel {}
