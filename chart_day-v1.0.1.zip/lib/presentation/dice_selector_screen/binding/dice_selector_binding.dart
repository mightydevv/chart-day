import '../controller/dice_selector_controller.dart';
import 'package:get/get.dart';

class DiceSelectorBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DiceSelectorController());
  }
}
