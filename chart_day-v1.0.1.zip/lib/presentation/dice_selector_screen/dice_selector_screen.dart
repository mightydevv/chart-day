import 'controller/dice_selector_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:chart_day/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

class DiceSelectorScreen extends GetWidget<DiceSelectorController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume2),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin: getMargin(left: 15, top: 13, right: 13)),
                  AppbarImage(
                      height: getVerticalSize(22),
                      width: getHorizontalSize(20),
                      svgPath: ImageConstant.imgPlay,
                      margin:
                          getMargin(left: 25, top: 17, right: 28, bottom: 4),
                      onTap: onTapPlay)
                ]),
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("msg_critical_hit_chart".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian20
                              .copyWith(letterSpacing: getHorizontalSize(0.8))),
                      Padding(
                          padding: getPadding(top: 31),
                          child: Text("msg_choose_your_dice".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium22.copyWith(
                                  letterSpacing: getHorizontalSize(0.44)))),
                      Align(
                          alignment: Alignment.centerRight,
                          child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              padding: getPadding(left: 71, top: 24),
                              child: IntrinsicWidth(
                                  child: Container(
                                      height: getVerticalSize(124),
                                      width: getHorizontalSize(319),
                                      child: Stack(
                                          alignment: Alignment.centerLeft,
                                          children: [
                                            Align(
                                                alignment: Alignment.topRight,
                                                child: Padding(
                                                    padding: getPadding(top: 5),
                                                    child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text("lbl_d100".tr,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              style: AppStyle
                                                                  .txtAlgerian80
                                                                  .copyWith(
                                                                      letterSpacing:
                                                                          getHorizontalSize(
                                                                              3.2))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 33,
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d20".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d12".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d10".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d8".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d6".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2)))),
                                                          Padding(
                                                              padding:
                                                                  getPadding(
                                                                      top: 8,
                                                                      bottom:
                                                                          8),
                                                              child: Text(
                                                                  "lbl_d4".tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .txtAlgerian80WhiteA700
                                                                      .copyWith(
                                                                          letterSpacing:
                                                                              getHorizontalSize(3.2))))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                    height:
                                                        getVerticalSize(124),
                                                    width:
                                                        getHorizontalSize(250),
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    5)),
                                                        border: Border.all(
                                                            color: ColorConstant
                                                                .lightBlueA7007f,
                                                            width:
                                                                getHorizontalSize(
                                                                    3)))))
                                          ]))))),
                      Padding(
                          padding: getPadding(top: 45),
                          child: Text("msg_choose_the_number".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium22.copyWith(
                                  letterSpacing: getHorizontalSize(0.44)))),
                      Container(
                          margin: getMargin(left: 71, top: 26, right: 69),
                          padding: getPadding(
                              left: 108, top: 21, right: 108, bottom: 21),
                          decoration: AppDecoration.outlineLightblueA7007f
                              .copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder5),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text("lbl_1".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtAlgerian60.copyWith(
                                        letterSpacing: getHorizontalSize(2.4)))
                              ])),
                      Padding(
                          padding: getPadding(top: 6),
                          child: Text("lbl_01_100".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: AppStyle.txtBradleyHandITC30.copyWith(
                                  letterSpacing: getHorizontalSize(1.2)))),
                      Container(
                          height: getVerticalSize(216),
                          width: getHorizontalSize(375),
                          margin: getMargin(top: 10, bottom: 5),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: fs.Svg(ImageConstant.imgGroup35),
                                  fit: BoxFit.cover)),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.bottomLeft,
                                child: Container(
                                    padding: getPadding(
                                        left: 44,
                                        top: 17,
                                        right: 44,
                                        bottom: 17),
                                    decoration:
                                        AppDecoration.outlineLightgreen600,
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_save".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterMedium13))
                                        ]))),
                            Align(
                                alignment: Alignment.center,
                                child: Container(
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: fs.Svg(
                                                ImageConstant.imgGroup35),
                                            fit: BoxFit.cover)),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          CustomButton(
                                              height: getVerticalSize(54),
                                              width: getHorizontalSize(122),
                                              text: "lbl_1d_100".tr,
                                              margin: getMargin(top: 162),
                                              variant: ButtonVariant
                                                  .OutlineBlack9003f,
                                              shape: ButtonShape.Square,
                                              fontStyle:
                                                  ButtonFontStyle.Algerian20)
                                        ])))
                          ]))
                    ]))));
  }

  onTapVolume2() {
    Get.toNamed(AppRoutes.chartNameScanScreen);
  }

  onTapPlay() {
    Get.toNamed(AppRoutes.rangeEditorMainScreen);
  }
}
