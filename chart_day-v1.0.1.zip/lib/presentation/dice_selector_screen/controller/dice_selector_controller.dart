import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/dice_selector_screen/models/dice_selector_model.dart';

class DiceSelectorController extends GetxController {
  Rx<DiceSelectorModel> diceSelectorModelObj = DiceSelectorModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
