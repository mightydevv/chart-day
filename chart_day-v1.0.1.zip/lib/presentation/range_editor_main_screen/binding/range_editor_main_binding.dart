import '../controller/range_editor_main_controller.dart';
import 'package:get/get.dart';

class RangeEditorMainBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RangeEditorMainController());
  }
}
