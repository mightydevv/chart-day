import 'controller/range_editor_main_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:chart_day/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class RangeEditorMainScreen extends GetWidget<RangeEditorMainController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume4),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin: getMargin(left: 15, top: 13, right: 13)),
                  AppbarImage(
                      height: getVerticalSize(22),
                      width: getHorizontalSize(20),
                      svgPath: ImageConstant.imgPlay,
                      margin:
                          getMargin(left: 25, top: 17, right: 28, bottom: 4))
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 7, right: 7),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("msg_critical_hit_chart".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian20
                              .copyWith(letterSpacing: getHorizontalSize(0.8))),
                      Padding(
                          padding: getPadding(top: 13),
                          child: Text("lbl_select_range".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium17.copyWith(
                                  letterSpacing: getHorizontalSize(0.34)))),
                      Padding(
                          padding: getPadding(top: 9),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomButton(
                                    height: getVerticalSize(70),
                                    width: getHorizontalSize(80),
                                    text: "lbl_1".tr),
                                Padding(
                                    padding:
                                        getPadding(left: 36, top: 8, bottom: 8),
                                    child: Text("lbl".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtAlgerian40.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(1.6)))),
                                CustomButton(
                                    height: getVerticalSize(70),
                                    width: getHorizontalSize(80),
                                    text: "lbl_33".tr,
                                    margin: getMargin(left: 40))
                              ])),
                      Padding(
                          padding: getPadding(left: 13, top: 33, right: 7),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: getHorizontalSize(19),
                                    child: Text("lbl_1_33".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtAlgerian15.copyWith(
                                            letterSpacing:
                                                getHorizontalSize(0.6)))),
                                Container(
                                    height: getVerticalSize(35),
                                    width: getHorizontalSize(309),
                                    margin: getMargin(bottom: 3),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        border: Border.all(
                                            color:
                                                ColorConstant.lightBlueA7007f,
                                            width: getHorizontalSize(2),
                                            strokeAlign: StrokeAlign.center)))
                              ])),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 6, top: 61, right: 50),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                        width: getHorizontalSize(29),
                                        child: Text("lbl_34_66".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle.txtAlgerian15
                                                .copyWith(
                                                    letterSpacing:
                                                        getHorizontalSize(
                                                            0.6)))),
                                    CustomImageView(
                                        svgPath:
                                            ImageConstant.imgClickableplace,
                                        height: getVerticalSize(34),
                                        width: getHorizontalSize(216),
                                        margin: getMargin(top: 2, bottom: 2))
                                  ]))),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(left: 6, top: 61, right: 50),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                        width: getHorizontalSize(31),
                                        child: Text("lbl_67_100".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style: AppStyle.txtAlgerian15
                                                .copyWith(
                                                    letterSpacing:
                                                        getHorizontalSize(
                                                            0.6)))),
                                    CustomImageView(
                                        svgPath:
                                            ImageConstant.imgClickableplace,
                                        height: getVerticalSize(34),
                                        width: getHorizontalSize(216),
                                        margin: getMargin(top: 2, bottom: 2))
                                  ]))),
                      Spacer(),
                      Container(
                          height: getVerticalSize(214),
                          width: getHorizontalSize(375),
                          margin: getMargin(bottom: 30),
                          decoration: AppDecoration.outlineBlack900,
                          child:
                              Stack(alignment: Alignment.bottomLeft, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgIphonekeyboard,
                                height: getVerticalSize(214),
                                width: getHorizontalSize(375),
                                radius: BorderRadius.only(
                                    bottomLeft:
                                        Radius.circular(getHorizontalSize(10)),
                                    bottomRight:
                                        Radius.circular(getHorizontalSize(10))),
                                alignment: Alignment.center),
                            CustomButton(
                                height: getVerticalSize(42),
                                width: getHorizontalSize(126),
                                text: "lbl_1d_100".tr,
                                margin: getMargin(left: 3, bottom: 4),
                                variant: ButtonVariant.OutlineBlack9003f_1,
                                padding: ButtonPadding.PaddingAll7,
                                fontStyle: ButtonFontStyle.Algerian20,
                                alignment: Alignment.bottomLeft)
                          ]))
                    ]))));
  }

  onTapVolume4() {
    Get.toNamed(AppRoutes.diceSelectorScreen);
  }
}
