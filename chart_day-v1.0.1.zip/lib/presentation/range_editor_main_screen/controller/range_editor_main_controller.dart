import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/range_editor_main_screen/models/range_editor_main_model.dart';

class RangeEditorMainController extends GetxController {
  Rx<RangeEditorMainModel> rangeEditorMainModelObj = RangeEditorMainModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
