import 'controller/chart_list_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:flutter/material.dart';

class ChartListScreen extends GetWidget<ChartListController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(top: 18, bottom: 18),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgUser,
                          height: getSize(30),
                          width: getSize(30),
                          alignment: Alignment.centerRight,
                          margin: getMargin(top: 2, right: 19),
                          onTap: () {
                            onTapImgUser();
                          }),
                      Padding(
                          padding: getPadding(left: 34, top: 9, right: 34),
                          child: Text("msg_christobol_tisledale_s".tr,
                              maxLines: null,
                              textAlign: TextAlign.center,
                              style: AppStyle.txtAlgerian25.copyWith(
                                  letterSpacing: getHorizontalSize(1.0)))),
                      GestureDetector(
                          onTap: () {
                            onTapHeadline();
                          },
                          child: Container(
                              height: getVerticalSize(38),
                              width: getHorizontalSize(389),
                              margin: getMargin(top: 52),
                              child:
                                  Stack(alignment: Alignment.center, children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: getVerticalSize(33),
                                        width: getHorizontalSize(389),
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: ColorConstant.black900,
                                                width: getHorizontalSize(1))))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Text("msg_critical_hit_chart".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                        style: AppStyle.txtBradleyHandITC30
                                            .copyWith(
                                                letterSpacing:
                                                    getHorizontalSize(1.2))))
                              ]))),
                      Padding(
                          padding: getPadding(top: 14),
                          child: Text("lbl_fumble_chart".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtBradleyHandITC30.copyWith(
                                  letterSpacing: getHorizontalSize(1.2)))),
                      Spacer(),
                      Container(
                          height: getVerticalSize(159),
                          width: double.maxFinite,
                          child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Align(
                                    alignment: Alignment.topCenter,
                                    child: Container(
                                        padding: getPadding(
                                            left: 76,
                                            top: 18,
                                            right: 76,
                                            bottom: 18),
                                        decoration:
                                            AppDecoration.outlineBlack9003f,
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 3),
                                                  child: Text(
                                                      "msg_create_new_chart".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtBradleyHandITC30
                                                          .copyWith(
                                                              letterSpacing:
                                                                  getHorizontalSize(
                                                                      1.2))))
                                            ]))),
                                Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                        height: getVerticalSize(90),
                                        width: double.maxFinite,
                                        child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                  alignment: Alignment.center,
                                                  child: Container(
                                                      height:
                                                          getVerticalSize(72),
                                                      width: double.maxFinite,
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .gray400))),
                                              CustomImageView(
                                                  imagePath: ImageConstant
                                                      .imgQuillremovebgpreview,
                                                  height: getSize(90),
                                                  width: getSize(90),
                                                  alignment: Alignment.center,
                                                  onTap: () {
                                                    onTapImgQuillremovebgpreview();
                                                  })
                                            ])))
                              ]))
                    ]))));
  }

  onTapImgUser() {
    Get.toNamed(AppRoutes.authorNameMainScreen);
  }

  onTapHeadline() {
    Get.toNamed(AppRoutes.comboRollerMainContainerScreen);
  }

  onTapImgQuillremovebgpreview() {
    Get.toNamed(AppRoutes.chartNameScanScreen);
  }
}
