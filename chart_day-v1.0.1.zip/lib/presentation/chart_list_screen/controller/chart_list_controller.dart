import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/chart_list_screen/models/chart_list_model.dart';

class ChartListController extends GetxController {
  Rx<ChartListModel> chartListModelObj = ChartListModel().obs;

  @override
  void onReady() {
    super.onReady();
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.toNamed(AppRoutes.comboRollerManualScreen);
    });
  }

  @override
  void onClose() {
    super.onClose();
  }
}
