class ChartListModel {}
