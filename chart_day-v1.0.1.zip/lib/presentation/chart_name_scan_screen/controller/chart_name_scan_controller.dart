import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/presentation/chart_name_scan_screen/models/chart_name_scan_model.dart';

class ChartNameScanController extends GetxController {
  Rx<ChartNameScanModel> chartNameScanModelObj = ChartNameScanModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
