import 'controller/chart_name_scan_controller.dart';
import 'package:chart_day/core/app_export.dart';
import 'package:chart_day/widgets/app_bar/appbar_image.dart';
import 'package:chart_day/widgets/app_bar/custom_app_bar.dart';
import 'package:chart_day/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class ChartNameScanScreen extends GetWidget<ChartNameScanController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(63),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(30),
                    width: getSize(30),
                    svgPath: ImageConstant.imgVolume,
                    margin: getMargin(left: 10, top: 13, bottom: 13),
                    onTap: onTapVolume7),
                actions: [
                  AppbarImage(
                      height: getSize(30),
                      width: getSize(30),
                      svgPath: ImageConstant.imgHome,
                      margin: getMargin(left: 15, top: 13, right: 13),
                      onTap: onTapHome4),
                  AppbarImage(
                      height: getVerticalSize(22),
                      width: getHorizontalSize(20),
                      svgPath: ImageConstant.imgPlay,
                      margin:
                          getMargin(left: 25, top: 17, right: 28, bottom: 4),
                      onTap: onTapPlay1)
                ]),
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("lbl_chart_s_name".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAlgerian30
                              .copyWith(letterSpacing: getHorizontalSize(1.2))),
                      Container(
                          height: getVerticalSize(124),
                          width: getHorizontalSize(295),
                          margin: getMargin(top: 23),
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.circular(getHorizontalSize(10)),
                              border: Border.all(
                                  color: ColorConstant.lightBlueA7007f,
                                  width: getHorizontalSize(2)))),
                      CustomButton(
                          height: getVerticalSize(30),
                          text: "lbl_or".tr,
                          margin: getMargin(top: 29),
                          variant: ButtonVariant.OutlineBlack900,
                          shape: ButtonShape.Square,
                          padding: ButtonPadding.PaddingAll3,
                          fontStyle: ButtonFontStyle.BradleyHandITC18),
                      Padding(
                          padding: getPadding(top: 28),
                          child: Text("lbl_upload".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAlgerian30.copyWith(
                                  letterSpacing: getHorizontalSize(1.2)))),
                      CustomImageView(
                          svgPath: ImageConstant.imgVector,
                          height: getVerticalSize(88),
                          width: getHorizontalSize(104),
                          margin: getMargin(top: 26)),
                      Container(
                          width: getHorizontalSize(375),
                          margin:
                              getMargin(left: 8, top: 72, right: 7, bottom: 5),
                          padding:
                              getPadding(left: 3, top: 4, right: 3, bottom: 4),
                          decoration: AppDecoration.outlineBlack900,
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                    height: getVerticalSize(42),
                                    width: getHorizontalSize(126),
                                    margin: getMargin(top: 164),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.blueGray300,
                                        borderRadius: BorderRadius.circular(
                                            getHorizontalSize(5)),
                                        boxShadow: [
                                          BoxShadow(
                                              color: ColorConstant.black9003f,
                                              spreadRadius:
                                                  getHorizontalSize(2),
                                              blurRadius: getHorizontalSize(2),
                                              offset: Offset(0, 4))
                                        ]))
                              ]))
                    ]))));
  }

  onTapVolume7() {
    Get.toNamed(AppRoutes.chartListScreen);
  }

  onTapHome4() {
    Get.toNamed(AppRoutes.chartListScreen);
  }

  onTapPlay1() {
    Get.toNamed(AppRoutes.diceSelectorScreen);
  }
}
