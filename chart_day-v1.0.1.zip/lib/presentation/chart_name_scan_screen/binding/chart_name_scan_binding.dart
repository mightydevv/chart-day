import '../controller/chart_name_scan_controller.dart';
import 'package:get/get.dart';

class ChartNameScanBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ChartNameScanController());
  }
}
