class ChartNameScanModel {}
