import 'package:chart_day/presentation/chart_list_screen/chart_list_screen.dart';
import 'package:chart_day/presentation/chart_list_screen/binding/chart_list_binding.dart';
import 'package:chart_day/presentation/combo_roller_manual_screen/combo_roller_manual_screen.dart';
import 'package:chart_day/presentation/combo_roller_manual_screen/binding/combo_roller_manual_binding.dart';
import 'package:chart_day/presentation/combo_roller_main_container_screen/combo_roller_main_container_screen.dart';
import 'package:chart_day/presentation/combo_roller_main_container_screen/binding/combo_roller_main_container_binding.dart';
import 'package:chart_day/presentation/dice_selector_screen/dice_selector_screen.dart';
import 'package:chart_day/presentation/dice_selector_screen/binding/dice_selector_binding.dart';
import 'package:chart_day/presentation/range_editor_3_1_screen/range_editor_3_1_screen.dart';
import 'package:chart_day/presentation/range_editor_3_1_screen/binding/range_editor_3_1_binding.dart';
import 'package:chart_day/presentation/range_editor_main_screen/range_editor_main_screen.dart';
import 'package:chart_day/presentation/range_editor_main_screen/binding/range_editor_main_binding.dart';
import 'package:chart_day/presentation/share_screen/share_screen.dart';
import 'package:chart_day/presentation/share_screen/binding/share_binding.dart';
import 'package:chart_day/presentation/author_name_main_screen/author_name_main_screen.dart';
import 'package:chart_day/presentation/author_name_main_screen/binding/author_name_main_binding.dart';
import 'package:chart_day/presentation/chart_name_scan_screen/chart_name_scan_screen.dart';
import 'package:chart_day/presentation/chart_name_scan_screen/binding/chart_name_scan_binding.dart';
import 'package:chart_day/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:chart_day/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String chartListScreen = '/chart_list_screen';

  static const String comboRollerManualScreen = '/combo_roller_manual_screen';

  static const String comboRollerMainPage = '/combo_roller_main_page';

  static const String comboRollerMainContainerScreen =
      '/combo_roller_main_container_screen';

  static const String diceSelectorScreen = '/dice_selector_screen';

  static const String rangeEditor31Screen = '/range_editor_3_1_screen';

  static const String rangeEditorMainScreen = '/range_editor_main_screen';

  static const String shareScreen = '/share_screen';

  static const String authorNameMainScreen = '/author_name_main_screen';

  static const String chartNameScanScreen = '/chart_name_scan_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: chartListScreen,
      page: () => ChartListScreen(),
      bindings: [
        ChartListBinding(),
      ],
    ),
    GetPage(
      name: comboRollerManualScreen,
      page: () => ComboRollerManualScreen(),
      bindings: [
        ComboRollerManualBinding(),
      ],
    ),
    GetPage(
      name: comboRollerMainContainerScreen,
      page: () => ComboRollerMainContainerScreen(),
      bindings: [
        ComboRollerMainContainerBinding(),
      ],
    ),
    GetPage(
      name: diceSelectorScreen,
      page: () => DiceSelectorScreen(),
      bindings: [
        DiceSelectorBinding(),
      ],
    ),
    GetPage(
      name: rangeEditor31Screen,
      page: () => RangeEditor31Screen(),
      bindings: [
        RangeEditor31Binding(),
      ],
    ),
    GetPage(
      name: rangeEditorMainScreen,
      page: () => RangeEditorMainScreen(),
      bindings: [
        RangeEditorMainBinding(),
      ],
    ),
    GetPage(
      name: shareScreen,
      page: () => ShareScreen(),
      bindings: [
        ShareBinding(),
      ],
    ),
    GetPage(
      name: authorNameMainScreen,
      page: () => AuthorNameMainScreen(),
      bindings: [
        AuthorNameMainBinding(),
      ],
    ),
    GetPage(
      name: chartNameScanScreen,
      page: () => ChartNameScanScreen(),
      bindings: [
        ChartNameScanBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => ChartListScreen(),
      bindings: [
        ChartListBinding(),
      ],
    )
  ];
}
