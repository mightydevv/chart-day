import 'package:chart_day/core/app_export.dart';

class ApiClient extends GetConnect {}
