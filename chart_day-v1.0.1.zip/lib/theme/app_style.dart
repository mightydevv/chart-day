import 'package:flutter/material.dart';
import 'package:chart_day/core/app_export.dart';

class AppStyle {
  static TextStyle txtBradleyHandITC30 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Bradley Hand ITC',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian60 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      60,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian80 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      80,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium13 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtInterMedium22 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      22,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtAlgerian30 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian20 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtInterMedium17 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtAlgerian40 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian25 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian15 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtBradleyHandITC18 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Bradley Hand ITC',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAlgerian80WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      80,
    ),
    fontFamily: 'Algerian',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtBradleyHandITC17 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Bradley Hand ITC',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );
}
