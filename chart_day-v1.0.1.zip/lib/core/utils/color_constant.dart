import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color gray400 = fromHex('#c8c7cc');

  static Color black900 = fromHex('#000000');

  static Color lightGreen600 = fromHex('#71af4b');

  static Color blueGray300 = fromHex('#8fadb5');

  static Color bluegray400 = fromHex('#888888');

  static Color gray900 = fromHex('#1c1b1b');

  static Color black9003f = fromHex('#3f000000');

  static Color whiteA700 = fromHex('#ffffff');

  static Color lightBlueA7007f = fromHex('#7f0a88e3');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
