class ImageConstant {
  static String imgQuillremovebgpreview =
      'assets/images/img_quillremovebgpreview.png';

  static String imgIphonekeyboard = 'assets/images/img_iphonekeyboard.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgClickableplace = 'assets/images/img_clickableplace.svg';

  static String imgCrossedswords3 = 'assets/images/img_crossedswords3.png';

  static String imgJjravenredwh = 'assets/images/img_jjravenredwh.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgPlay = 'assets/images/img_play.svg';

  static String imgDicetrayremovebgpreview =
      'assets/images/img_dicetrayremovebgpreview.png';

  static String imgImg42191 = 'assets/images/img_img42191.png';

  static String imgQrpng1 = 'assets/images/img_qrpng1.png';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgScrollnoborde = 'assets/images/img_scrollnoborde.png';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgGroup35 = 'assets/images/img_group35.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
